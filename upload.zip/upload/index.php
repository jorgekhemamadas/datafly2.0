<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DataFly</title>
<link rel="icon" type="image/png" href="https://raw.githubusercontent.com/jorgekhemamadas/Im-genes-datafly/main/subir%20(1).png" sizes="512x512">

<style>
    /* Estilo para centrar la imagen */
    .centered-image {
        width: 100%;
        display: block;
        margin: 0 auto; /* Esto centra horizontalmente */
    }
</style>

<?php
// URL de la imagen en GitHub
$imageUrl = 'https://raw.githubusercontent.com/jorgekhemamadas/Im-genes-datafly/main/anon.jpg';

// Código PHP para mostrar la imagen centrada
echo '<img src="' . $imageUrl . '" alt="Imagen" class="centered-image">';
?>
    <style>
body {
    background-color: black;
    color: white; /* Para asegurar que el texto sea legible en el fondo negro */
}
        body {
            font-family: Arial, sans-serif;
            background-color: black; /* Fondo negro */
            color: white; /* Texto blanco */
            padding: 20px;
        }
        h1 {
            text-align: center;
        }
#downloadLink {
display: block;
text-align: center;
cursor: none;
        }
         #copyButton {
            display: block;
            margin: 10px auto;
            text-align: center;
            background-color: #797980; /* Estilo del botón invertido */
            color: #CCCCCC; /* Texto en negro */
            border: none;
            padding: 10px 100px;
            border-radius: 5px;
            cursor: pointer;
        //    transition: background-color 0.3s ease;
            font-family: 'Open Sans', sans-serif; /* Tipo de letra cool */
        }
        #copyButton:hover {
        display: block;
            margin: 10px auto;
            text-align: center;
            background-color: #797980; /* Estilo del botón invertido */
            color: #CCCCCC; /* Texto en negro */
            border: none;
            padding: 10px 100px;
            border-radius: 5px;
            cursor: pointer;
      //      transition: background-color 0.3s ease;
            font-family: 'Open Sans', sans-serif; /* Tipo de letra cool */
        }
        input[type="file"] {
            display: none; /* Ocultar el input de tipo file */
        }
        label {
            display: block;
            margin: 10px auto;
            text-align: center;
            background-color: #797980; /* Estilo del botón invertido */
            color: black; /* Texto en negro */
            border: none;
            padding: 10px 100px;
            border-radius: 5px;
            cursor: pointer;
    //        transition: background-color 0.3s ease;
            width: 100px;
            font-family: 'Open Sans', sans-serif; /* Tipo de letra cool */
        }
        label:hover {
        display: block;
            margin: 10px auto;
            text-align: center;
            background-color: #797980; /* Estilo del botón invertido */
            color: #CCCCCC;; /* Texto en negro */
            border: none;
            padding: 10px 100px;
            border-radius: 5px;
            cursor: pointer;
  //          transition: background-color 0.3s ease;
            font-family: 'Open Sans', sans-serif; /* Tipo de letra cool */
        }

        label {
    display: block;
    margin: 20px auto;
    text-align: center;
    background-color: #797980; /* Estilo del botón invertido */
    color: #CCCCCC;; /* Texto en negro */
    border: none;
    padding: 10px 100px; /* Ajusta el padding horizontal para hacer el botón más largo */
    border-radius: 5px;
    cursor: pointer;
//    transition: background-color 0.3s ease;
    font-family: 'Open Sans', sans-serif; /* Tipo de letra cool */
}

    .footer-text {
            position: fixed;
            bottom: 0;
            left: 0;
            width: 100%;
            text-align: center;
            background-color: black;
            padding: 10px 0;
        }

       label img {
  width: 25px; /* ajusta el tamaño según necesites */
  height: 25px;
  margin-left: 1px; /* ajusta el espacio entre el texto y el icono */
}
    </style>
</head>
<body>
    <form id="uploadForm" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" enctype="multipart/form-data">
        <h4 style="text-align: center; color: #CCCCCC; ">𝘿𝙖𝙩𝙖𝙁𝙡𝙮 𝙐𝙥𝙡𝙤𝙖𝙙</h4>
        <input type="file" name="files[]" id="fileInput" multiple onchange="submitForm()">
<label for="fileInput">ᴜᴘʟᴏᴀᴅ<img src="https://raw.githubusercontent.com/jorgekhemamadas/Im-genes-datafly/main/subir%20(1).png" alt="Upload Icon"></label>
<h5 style="text-align: center; color: #CCCCCC;">𝙎𝙪𝙗𝙚 𝙩𝙪𝙨 𝙖𝙧𝙘𝙝𝙞𝙫𝙤𝙨 𝙙𝙚 𝙛𝙤𝙧𝙢𝙖 𝙖𝙣𝙤𝙣𝙞𝙢𝙖</h5>
<h5 style="text-align: center; color: #CCCCCC;">𝘾𝘼𝙋𝘼𝘾𝙄𝘿𝘼𝘿 𝙇𝙄𝙈𝙄𝙏𝘼𝘿𝘼</h5>
    </form>

    <?php
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['files'])) {
        $uploadDir = '/var/www/html/archivos/';
        $userPrefix = 'datafly-';

        // Obtener el nombre del usuario (puedes obtenerlo de tu sistema de autenticación)
//        $userName = 'usuario01';

        // Crear el nombre del archivo zip con el prefijo del usuario y un número único
        $zipFileName = $uploadDir . $userPrefix . uniqid() . '.zip';

        // Crear un nuevo archivo zip
        $zip = new ZipArchive();
        if ($zip->open($zipFileName, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== TRUE) {
            echo 'Error al crear el archivo zip.';
            exit;
        }

        // Iterar sobre cada archivo subido y agregarlo al archivo zip
        foreach ($_FILES['files']['tmp_name'] as $key => $tmp_name) {
            $fileName = $_FILES['files']['name'][$key];
            $filePath = $_FILES['files']['tmp_name'][$key];
            // Agregar el archivo al archivo zip
            if (!$zip->addFile($filePath, $fileName)) {
                echo '<span style="color: red;">Error! selecciona por lo menos ' . $fileName . ' un archivo.</span>';
                $zip->close();
                exit;
            }
        }

        // Cerrar el archivo zip
        $zip->close();

        // Generar el enlace de descarga del archivo zip
        $downloadLink = 'https://vps-50bc0927.vps.ovh.net/archivos/' . urlencode(basename($zipFileName));
  //      echo '<a id="downloadLink" href="' . $downloadLink . '" download>𝗗𝗲𝘀𝗰𝗮𝗿𝗴𝗮𝗿 𝗮𝗿𝗰𝗵𝗶𝘃𝗼𝘀 𝗰𝗼𝗺𝗽𝗿𝗶𝗺𝗶𝗱𝗼𝘀</a>';
        echo '<button id="copyButton" onclick="copyToClipboard(\'' . $downloadLink . '\')">𝘾𝙤𝙥𝙞𝙖𝙧 𝙚𝙣𝙡𝙖𝙘𝙚 𝙙𝙚 𝙙𝙚𝙨𝙘𝙖𝙧𝙜𝙖</button>';
        echo '<br>';
    } else {
        echo '';
    }
    ?>

    <script>
        function submitForm() {
            document.getElementById("uploadForm").submit();
        }

        function copyToClipboard(text) {
            var textarea = document.createElement("textarea");
            textarea.textContent = text;
            document.body.appendChild(textarea);
            textarea.select();
            document.execCommand("copy");
            document.body.removeChild(textarea);
            alert("Enlace copiado al portapapeles: " + text);
        }
    </script>

<div class="footer-text">
    <p>𝕮𝖗𝖊𝖆𝖙𝖊 𝖇𝖞 𝖏𝖔𝖗𝖌𝖊𝖐𝖍𝖊𝖒𝖆𝖒𝖆𝖉𝖆𝖘</p>
</div>

</body>
</html>
